import os
from datetime import datetime


def _parse_csv_linha(linha):
    campos = []
    atual = []
    i = 0
    n = len(linha)
    aspas = False
    while i < n:
        c = linha[i]
        if c == "\r":
            i += 1
            continue
        if aspas:
            if c == '"':
                if i + 1 < n and linha[i + 1] == '"':
                    atual.append('"')
                    i += 2
                    continue
                aspas = False
                i += 1
                continue
            atual.append(c)
        else:
            if c == '"':
                aspas = True
            elif c == ",":
                campos.append("".join(atual))
                atual = []
            else:
                atual.append(c)
        i += 1
    campos.append("".join(atual))
    return campos


class Jogo:
    def __init__(self, id_jogo, titulo, console, genero, publisher, developer, critic_score, total_sales, na_sales, jp_sales, pal_sales, other_sales, release_date):
        self.id = id_jogo
        self.titulo = titulo
        self.console = console
        self.genero = genero
        self.publisher = publisher
        self.developer = developer
        self.critic_score = critic_score
        self.total_sales = total_sales
        self.na_sales = na_sales
        self.jp_sales = jp_sales
        self.pal_sales = pal_sales
        self.other_sales = other_sales
        self.release_date = release_date

    def __str__(self):
        return f"{self.id} - {self.titulo} ({self.console}) | Gênero: {self.genero} | Nota: {self.critic_score}"


class FilaBacklog:
    def __init__(self):
        self.fila = []

    def enqueue(self, jogo):
        self.fila.append(jogo)
        print(f"  -> '{jogo.titulo}' adicionado ao backlog (posição {len(self.fila)})")

    def dequeue(self):
        if self.is_empty():
            print("  Backlog vazio! Nada para jogar.")
            return None
        jogo = self.fila.pop(0)
        print(f"  -> Jogando agora: '{jogo.titulo}' (removido do início da fila)")
        return jogo

    def is_empty(self):
        return len(self.fila) == 0

    def mostrar(self):
        if self.is_empty():
            print("  Seu backlog está vazio. Adicione jogos para jogar depois!")
            return
        print("\n  === SEU BACKLOG (próximos jogos) ===")
        for i, jogo in enumerate(self.fila, 1):
            print(f"  {i}. {jogo.titulo} ({jogo.console}) - Gênero: {jogo.genero}")
        print(f"  Total: {len(self.fila)} jogo(s) na fila")

    def tamanho(self):
        return len(self.fila)


class PilhaRecentes:
    def __init__(self):
        self.pilha = []
        self.limite = 20

    def push(self, jogo):
        self.pilha = [j for j in self.pilha if j.titulo != jogo.titulo]
        self.pilha.append(jogo)
        if len(self.pilha) > self.limite:
            self.pilha.pop(0)
        print(f"  -> '{jogo.titulo}' adicionado aos jogos recentes!")

    def pop(self):
        if self.is_empty():
            print("  Nenhum jogo recente!")
            return None
        return self.pilha.pop()

    def topo(self):
        if self.is_empty():
            return None
        return self.pilha[-1]

    def is_empty(self):
        return len(self.pilha) == 0

    def mostrar(self):
        if self.is_empty():
            print("  Nenhum jogo recente ainda. Comece a jogar!")
            return
        print("\n  === JOGOS RECENTES (do mais novo para o mais velho) ===")
        for i, jogo in enumerate(reversed(self.pilha), 1):
            print(f"  {i}. {jogo.titulo} ({jogo.console})")
        print(f"  Total: {len(self.pilha)} jogo(s) recentes")

    def tamanho(self):
        return len(self.pilha)


class BatataBios:
    def __init__(self):
        self.catalogo = []
        self.jogos_dict = {}
        self.backlog = FilaBacklog()
        self.recentes = PilhaRecentes()
        self.historico = []
        self.tempos_acumulados = {}
        self.status_jogo = {}
        self.genero_tempo = {}
        self.console_tempo = {}
        self.sessao_contador = 0

    def carregar_jogos(self, nome_arquivo="dataset.csv"):
        print(f"\n[Carregando catálogo de '{nome_arquivo}'...]")
        self.catalogo = []
        self.jogos_dict = {}

        if not os.path.exists(nome_arquivo):
            print(f"  ERRO: Arquivo '{nome_arquivo}' não encontrado!")
            print("  Criando catálogo vazio para testes...")
            return False

        try:
            with open(nome_arquivo, 'r', encoding='utf-8') as arquivo:
                next(arquivo)

                id_atual = 1
                for linha_bruta in arquivo:
                    linha = _parse_csv_linha(linha_bruta.rstrip("\r\n"))
                    if len(linha) < 14:
                        continue

                    try:
                        titulo = linha[1].strip()
                        console = linha[2].strip()
                        genero = linha[3].strip()
                        publisher = linha[4].strip()
                        developer = linha[5].strip()
                        critic_score = float(linha[6]) if linha[6] else 0.0
                        total_sales = float(linha[7]) if linha[7] else 0.0
                        na_sales = float(linha[8]) if linha[8] else 0.0
                        jp_sales = float(linha[9]) if linha[9] else 0.0
                        pal_sales = float(linha[10]) if linha[10] else 0.0
                        other_sales = float(linha[11]) if linha[11] else 0.0
                        release_date = linha[12].strip()

                        jogo = Jogo(id_atual, titulo, console, genero, publisher, developer,
                                    critic_score, total_sales, na_sales, jp_sales,
                                    pal_sales, other_sales, release_date)

                        self.catalogo.append(jogo)
                        self.jogos_dict[id_atual] = jogo
                        id_atual += 1

                    except (ValueError, IndexError) as e:
                        print(f"  Aviso: linha ignorada (erro: {e})")
                        continue

            print(f"  Sucesso! {len(self.catalogo)} jogos carregados no catálogo.")
            return True

        except Exception as e:
            print(f"  Erro ao carregar: {e}")
            return False

    def listar_jogos(self, lista=None, titulo_lista="CATÁLOGO COMPLETO"):
        if lista is None:
            lista = self.catalogo

        if not lista:
            print("  Nenhum jogo encontrado.")
            return

        print(f"\n  === {titulo_lista} ({len(lista)} jogos) ===")
        for jogo in lista:
            status = self.status_jogo.get(jogo.titulo, "não jogado")
            tempo = self.tempos_acumulados.get(jogo.titulo, 0.0)
            print(f"  {jogo.id:3}. {jogo.titulo[:40]:<40} | {jogo.console:<12} | Nota: {jogo.critic_score:4.1f} | Tempo: {tempo:5.1f}h | Status: {status}")

    def buscar_jogo_por_nome(self, termo):
        termo = termo.lower()
        resultados = [j for j in self.catalogo if termo in j.titulo.lower()]

        if not resultados:
            print(f"  Nenhum jogo encontrado com '{termo}' no nome.")
            return []

        print(f"\n  === RESULTADOS DA BUSCA POR '{termo}' ===")
        self.listar_jogos(resultados, f"BUSCA: {termo}")
        return resultados

    def filtrar_por_genero(self, genero):
        resultados = [j for j in self.catalogo if genero.lower() in j.genero.lower()]
        if resultados:
            self.listar_jogos(resultados, f"FILTRO GÊNERO: {genero}")
        else:
            print(f"  Nenhum jogo do gênero '{genero}' encontrado.")
        return resultados

    def filtrar_por_console(self, console):
        resultados = [j for j in self.catalogo if console.lower() in j.console.lower()]
        if resultados:
            self.listar_jogos(resultados, f"FILTRO CONSOLE: {console}")
        else:
            print(f"  Nenhum jogo do console '{console}' encontrado.")
        return resultados

    def filtrar_por_nota(self, nota_minima):
        try:
            nota = float(nota_minima)
        except:
            print("  Nota inválida! Use número como 80 ou 85.")
            return []

        resultados = [j for j in self.catalogo if j.critic_score >= nota]
        if resultados:
            self.listar_jogos(resultados, f"FILTRO NOTA MÍNIMA: {nota}")
        else:
            print(f"  Nenhum jogo com nota >= {nota} encontrado.")
        return resultados

    def filtrar_por_vendas(self, vendas_minimas):
        try:
            vendas = float(vendas_minimas)
        except:
            print("  Valor inválido!")
            return []

        resultados = [j for j in self.catalogo if j.total_sales >= vendas]
        if resultados:
            self.listar_jogos(resultados, f"FILTRO VENDAS MÍNIMAS: {vendas} milhões")
        else:
            print(f"  Nenhum jogo com vendas >= {vendas}M encontrado.")
        return resultados

    def filtrar_por_publisher(self, publisher):
        resultados = [j for j in self.catalogo if publisher.lower() in j.publisher.lower()]
        if resultados:
            self.listar_jogos(resultados, f"FILTRO PUBLISHER: {publisher}")
        else:
            print(f"  Nenhum jogo da publisher '{publisher}' encontrado.")
        return resultados

    def ordenar_jogos(self, criterio):
        if not self.catalogo:
            print("  Catálogo vazio!")
            return

        if criterio == "1":
            ordenado = sorted(self.catalogo, key=lambda j: j.titulo)
            titulo = "ORDENADO POR TÍTULO (A-Z)"
        elif criterio == "2":
            ordenado = sorted(self.catalogo, key=lambda j: j.critic_score, reverse=True)
            titulo = "ORDENADO POR NOTA (MAIOR PARA MENOR)"
        elif criterio == "3":
            ordenado = sorted(self.catalogo, key=lambda j: j.total_sales, reverse=True)
            titulo = "ORDENADO POR VENDAS TOTAIS (MAIOR PARA MENOR)"
        elif criterio == "4":
            ordenado = sorted(self.catalogo, key=lambda j: j.release_date, reverse=True)
            titulo = "ORDENADO POR DATA DE LANÇAMENTO (MAIS NOVO)"
        elif criterio == "5":
            ordenado = sorted(self.catalogo, key=lambda j: j.console)
            titulo = "ORDENADO POR CONSOLE (A-Z)"
        elif criterio == "6":
            ordenado = sorted(self.catalogo, key=lambda j: j.genero)
            titulo = "ORDENADO POR GÊNERO (A-Z)"
        else:
            print("  Critério inválido!")
            return

        self.listar_jogos(ordenado, titulo)

    def adicionar_ao_backlog(self):
        print("\n  === ADICIONAR JOGO AO BACKLOG ===")
        self.listar_jogos()

        try:
            id_escolhido = int(input("\n  Digite o ID do jogo que quer adicionar ao backlog: "))
            if id_escolhido in self.jogos_dict:
                jogo = self.jogos_dict[id_escolhido]
                if any(j.titulo == jogo.titulo for j in self.backlog.fila):
                    print("  Este jogo já está no seu backlog!")
                else:
                    self.backlog.enqueue(jogo)
            else:
                print("  ID inválido!")
        except ValueError:
            print("  Digite apenas números!")

    def mostrar_backlog(self):
        self.backlog.mostrar()

    def jogar_proximo_do_backlog(self):
        print("\n  === JOGAR PRÓXIMO DO BACKLOG ===")
        jogo = self.backlog.dequeue()
        if jogo:
            self.iniciar_jogo(jogo, vindo_do_backlog=True)

    def salvar_backlog(self, nome_arquivo="backlog.txt"):
        try:
            with open(nome_arquivo, 'w', encoding='utf-8') as f:
                for jogo in self.backlog.fila:
                    f.write(f"{jogo.id};{jogo.titulo};{jogo.console}\n")
            print(f"  Backlog salvo em '{nome_arquivo}' com {len(self.backlog.fila)} jogo(s).")
        except Exception as e:
            print(f"  Erro ao salvar backlog: {e}")

    def carregar_backlog(self, nome_arquivo="backlog.txt"):
        if not os.path.exists(nome_arquivo):
            print("  Nenhum backlog salvo encontrado (arquivo não existe).")
            return

        try:
            with open(nome_arquivo, 'r', encoding='utf-8') as f:
                for linha in f:
                    partes = linha.strip().split(';')
                    if len(partes) >= 3:
                        id_jogo = int(partes[0])
                        if id_jogo in self.jogos_dict:
                            self.backlog.enqueue(self.jogos_dict[id_jogo])
            print(f"  Backlog carregado com {len(self.backlog.fila)} jogo(s).")
        except Exception as e:
            print(f"  Erro ao carregar backlog: {e}")

    def mostrar_recentes(self):
        self.recentes.mostrar()

    def retomar_ultimo_jogo(self):
        print("\n  === RETOMAR ÚLTIMO JOGO ===")
        if self.recentes.is_empty():
            print("  Nenhum jogo recente para retomar!")
            return

        jogo = self.recentes.topo()
        print(f"  Jogo mais recente: {jogo.titulo} ({jogo.console})")

        opcao = input("  Quer retomar este jogo agora? (s/n): ").lower()
        if opcao == 's':
            self.iniciar_jogo(jogo, retomando=True)

    def salvar_recentes(self, nome_arquivo="recentes.txt"):
        try:
            with open(nome_arquivo, 'w', encoding='utf-8') as f:
                for jogo in self.recentes.pilha:
                    f.write(f"{jogo.id};{jogo.titulo};{jogo.console}\n")
            print(f"  Recentes salvos ({len(self.recentes.pilha)} jogos).")
        except Exception as e:
            print(f"  Erro: {e}")

    def carregar_recentes(self, nome_arquivo="recentes.txt"):
        if not os.path.exists(nome_arquivo):
            return
        try:
            with open(nome_arquivo, 'r', encoding='utf-8') as f:
                linhas = f.readlines()
                for linha in linhas:
                    partes = linha.strip().split(';')
                    if len(partes) >= 3:
                        id_jogo = int(partes[0])
                        if id_jogo in self.jogos_dict:
                            self.recentes.push(self.jogos_dict[id_jogo])
            print(f"  {len(self.recentes.pilha)} jogos recentes carregados.")
        except:
            pass

    def iniciar_jogo(self, jogo, vindo_do_backlog=False, retomando=False):
        print(f"\n  === INICIANDO / RETOMANDO: {jogo.titulo} ===")

        tempo_atual = self.tempos_acumulados.get(jogo.titulo, 0.0)
        print(f"  Tempo já jogado neste título: {tempo_atual:.1f} horas")

        try:
            tempo_str = input("  Quantas horas jogou nesta sessão? (ex: 2.5 ou 1): ").replace(',', '.')
            tempo_sessao = float(tempo_str)
            if tempo_sessao <= 0:
                print("  Tempo inválido!")
                return
        except:
            print("  Valor inválido! Sessão cancelada.")
            return

        if jogo.titulo not in self.tempos_acumulados:
            self.tempos_acumulados[jogo.titulo] = 0.0
        self.tempos_acumulados[jogo.titulo] += tempo_sessao

        novo_total = self.tempos_acumulados[jogo.titulo]

        if novo_total < 2:
            status = "iniciado"
        elif novo_total < 10:
            status = "em_andamento"
        elif novo_total < 20:
            status = "muito_jogado"
        else:
            status = "concluido_simbolicamente"

        self.status_jogo[jogo.titulo] = status

        self.sessao_contador += 1
        data_atual = datetime.now().strftime("%Y-%m-%d %H:%M")
        sessao = {
            "titulo": jogo.titulo,
            "tempo_sessao": tempo_sessao,
            "tempo_total": novo_total,
            "status": status,
            "data": data_atual,
            "sessao_num": self.sessao_contador
        }
        self.historico.append(sessao)

        self._atualizar_estatisticas(jogo, tempo_sessao)

        self.recentes.push(jogo)

        print(f"\n  Sessão registrada com sucesso!")
        print(f"  Tempo desta sessão: {tempo_sessao:.1f}h")
        print(f"  Tempo total neste jogo: {novo_total:.1f}h")
        print(f"  Status atual: {status}")

        if not vindo_do_backlog:
            if not any(j.titulo == jogo.titulo for j in self.backlog.fila):
                op = input("  Quer adicionar este jogo ao backlog para jogar depois? (s/n): ").lower()
                if op == 's':
                    self.backlog.enqueue(jogo)

    def _atualizar_estatisticas(self, jogo, tempo):
        if jogo.genero not in self.genero_tempo:
            self.genero_tempo[jogo.genero] = 0.0
        self.genero_tempo[jogo.genero] += tempo

        if jogo.console not in self.console_tempo:
            self.console_tempo[jogo.console] = 0.0
        self.console_tempo[jogo.console] += tempo

    def registrar_sessao_manual(self):
        print("\n  === REGISTRAR TEMPO DE JOGO ===")
        print("  Primeiro, escolha o jogo:")
        self.listar_jogos()

        try:
            id_escolhido = int(input("\n  Digite o ID do jogo: "))
            if id_escolhido in self.jogos_dict:
                jogo = self.jogos_dict[id_escolhido]
                self.iniciar_jogo(jogo)
            else:
                print("  ID inválido!")
        except:
            print("  Entrada inválida!")

    def mostrar_historico(self):
        print("\n  === HISTÓRICO COMPLETO DE SESSÕES ===")
        if not self.historico:
            print("  Ainda não há sessões registradas. Comece a jogar!")
            return

        print(f"  Total de sessões: {len(self.historico)}")
        print("-" * 80)
        for s in self.historico:
            print(f"  Sessão {s['sessao_num']:2} | {s['data']} | {s['titulo'][:35]:<35}")
            print(f"           Tempo sessão: {s['tempo_sessao']:5.1f}h | Total: {s['tempo_total']:5.1f}h | Status: {s['status']}")
        print("-" * 80)

    def salvar_historico(self, nome_arquivo="historico_jogo.txt"):
        try:
            with open(nome_arquivo, 'w', encoding='utf-8') as f:
                f.write("titulo;tempo_sessao;tempo_total;status;data\n")
                for s in self.historico:
                    f.write(f"{s['titulo']};{s['tempo_sessao']};{s['tempo_total']};{s['status']};{s['data']}\n")
            print(f"  Histórico salvo ({len(self.historico)} sessões).")
        except Exception as e:
            print(f"  Erro ao salvar: {e}")

    def carregar_historico(self, nome_arquivo="historico_jogo.txt"):
        if not os.path.exists(nome_arquivo):
            return
        try:
            with open(nome_arquivo, 'r', encoding='utf-8') as f:
                next(f)
                for linha in f:
                    partes = linha.strip().split(';')
                    if len(partes) >= 5:
                        self.historico.append({
                            "titulo": partes[0],
                            "tempo_sessao": float(partes[1]),
                            "tempo_total": float(partes[2]),
                            "status": partes[3],
                            "data": partes[4],
                            "sessao_num": len(self.historico) + 1
                        })
                        titulo = partes[0]
                        if titulo not in self.tempos_acumulados:
                            self.tempos_acumulados[titulo] = 0.0
                        self.tempos_acumulados[titulo] = float(partes[2])
                        self.status_jogo[titulo] = partes[3]
            print(f"  Histórico carregado com {len(self.historico)} sessões.")
        except:
            pass

    def recomendar_jogos(self):
        print("\n  === RECOMENDAÇÕES PERSONALIZADAS ===")

        if not self.tempos_acumulados:
            print("  Ainda não jogou nada. Recomendações baseadas no catálogo geral:")
            top = sorted(self.catalogo, key=lambda j: j.critic_score, reverse=True)[:5]
            for j in top:
                print(f"  - {j.titulo} ({j.console}) - Nota: {j.critic_score}")
            return

        if self.genero_tempo:
            genero_fav = max(self.genero_tempo, key=self.genero_tempo.get)
            tempo_gen = self.genero_tempo[genero_fav]
        else:
            genero_fav = "Action-Adventure"
            tempo_gen = 0

        if self.console_tempo:
            console_fav = max(self.console_tempo, key=self.console_tempo.get)
        else:
            console_fav = "Nintendo Switch"

        notas_jogados = [j.critic_score for j in self.catalogo if j.titulo in self.tempos_acumulados]
        nota_media = sum(notas_jogados) / len(notas_jogados) if notas_jogados else 85

        print(f"  Seu perfil:")
        print(f"  - Gênero favorito: {genero_fav} ({tempo_gen:.1f}h)")
        print(f"  - Console favorito: {console_fav}")
        print(f"  - Nota média dos jogos jogados: {nota_media:.1f}")

        recomendados = []
        for jogo in self.catalogo:
            if self.tempos_acumulados.get(jogo.titulo, 0) > 15:
                continue
            if any(j.titulo == jogo.titulo for j in self.backlog.fila):
                continue
            if (jogo.genero == genero_fav or jogo.console == console_fav) and jogo.critic_score >= (nota_media - 5):
                recomendados.append(jogo)

        if not recomendados:
            recomendados = sorted(self.catalogo, key=lambda j: j.critic_score, reverse=True)[:8]

        print(f"\n  === SUGESTÕES PARA VOCÊ ({len(recomendados)} jogos) ===")
        print(f"  Critérios usados: Gênero/Console favorito + Nota alta + Ainda não muito jogado")
        for i, j in enumerate(recomendados[:8], 1):
            tempo = self.tempos_acumulados.get(j.titulo, 0)
            print(f"  {i}. {j.titulo} ({j.console}) | Nota: {j.critic_score} | Gênero: {j.genero} | Já jogado: {tempo:.1f}h")

    def gerar_ranking_pessoal(self):
        print("\n  === RANKING PESSOAL ===")

        if not self.tempos_acumulados:
            print("  Ainda não há dados de jogo. Jogue algo primeiro!")
            return

        print("\n  --- TOP 5 JOGOS MAIS JOGADOS ---")
        ranking_tempo = sorted(self.tempos_acumulados.items(), key=lambda x: x[1], reverse=True)[:5]
        for i, (titulo, tempo) in enumerate(ranking_tempo, 1):
            status = self.status_jogo.get(titulo, "?")
            print(f"  {i}. {titulo[:40]:<40} | {tempo:6.1f}h | Status: {status}")

        print("\n  --- GÊNEROS MAIS JOGADOS ---")
        if self.genero_tempo:
            ranking_genero = sorted(self.genero_tempo.items(), key=lambda x: x[1], reverse=True)
            for i, (gen, tempo) in enumerate(ranking_genero[:5], 1):
                print(f"  {i}. {gen:<20} | {tempo:6.1f}h")

        print("\n  --- CONSOLES MAIS USADOS ---")
        if self.console_tempo:
            ranking_console = sorted(self.console_tempo.items(), key=lambda x: x[1], reverse=True)
            for i, (con, tempo) in enumerate(ranking_console[:5], 1):
                print(f"  {i}. {con:<20} | {tempo:6.1f}h")

        print("\n  --- MELHORES JOGOS JOGADOS (por nota) ---")
        jogados_com_nota = [(j.titulo, j.critic_score) for j in self.catalogo if j.titulo in self.tempos_acumulados]
        if jogados_com_nota:
            top_nota = sorted(jogados_com_nota, key=lambda x: x[1], reverse=True)[:5]
            for i, (titulo, nota) in enumerate(top_nota, 1):
                print(f"  {i}. {titulo[:40]:<40} | Nota: {nota}")

    def exibir_dashboard(self):
        print("\n" + "=" * 60)
        print("           BatataBios - DASHBOARD DO JOGADOR")
        print("=" * 60)

        total_catalogo = len(self.catalogo)
        total_backlog = self.backlog.tamanho()
        total_recentes = self.recentes.tamanho()
        total_sessoes = len(self.historico)
        tempo_total = sum(self.tempos_acumulados.values())

        if self.tempos_acumulados:
            jogo_mais = max(self.tempos_acumulados, key=self.tempos_acumulados.get)
            tempo_mais = self.tempos_acumulados[jogo_mais]
        else:
            jogo_mais = "Nenhum"
            tempo_mais = 0

        genero_fav = max(self.genero_tempo, key=self.genero_tempo.get) if self.genero_tempo else "Nenhum"

        console_fav = max(self.console_tempo, key=self.console_tempo.get) if self.console_tempo else "Nenhum"

        notas = [j.critic_score for j in self.catalogo if j.titulo in self.tempos_acumulados]
        nota_media = sum(notas) / len(notas) if notas else 0.0

        iniciados = sum(1 for s in self.status_jogo.values() if s == "iniciado")
        em_andamento = sum(1 for s in self.status_jogo.values() if s == "em_andamento")
        muito_jogados = sum(1 for s in self.status_jogo.values() if s == "muito_jogado")
        concluidos = sum(1 for s in self.status_jogo.values() if s == "concluido_simbolicamente")

        if self.historico:
            media_sessao = sum(s['tempo_sessao'] for s in self.historico) / len(self.historico)
        else:
            media_sessao = 0.0

        print(f"  📚 CATÁLOGO TOTAL:        {total_catalogo} jogos")
        print(f"  📋 BACKLOG:               {total_backlog} jogos para jogar")
        print(f"  ⏱️  RECENTES:              {total_recentes} jogos")
        print(f"  🎮 SESSÕES JOGADAS:       {total_sessoes}")
        print(f"  ⏰ TEMPO TOTAL JOGADO:    {tempo_total:.1f} horas")
        print()
        print(f"  🏆 JOGO MAIS JOGADO:      {jogo_mais} ({tempo_mais:.1f}h)")
        print(f"  🎨 GÊNERO FAVORITO:       {genero_fav}")
        print(f"  🖥️  CONSOLE FAVORITO:      {console_fav}")
        print(f"  ⭐ NOTA MÉDIA JOGADOS:    {nota_media:.1f}/100")
        print()
        print(f"  🟢 INICIADOS:             {iniciados} jogos")
        print(f"  🟡 EM ANDAMENTO:          {em_andamento} jogos")
        print(f"  🟠 MUITO JOGADOS:         {muito_jogados} jogos")
        print(f"  🟣 CONCLUÍDOS (simb.):    {concluidos} jogos")
        print()
        print(f"  📊 MÉDIA HORAS/SESSÃO:    {media_sessao:.1f}h")
        print(f"  💡 RECOMENDAÇÕES:         {len(self.catalogo) - len(self.tempos_acumulados)} disponíveis")
        print("=" * 60)

    def salvar_tudo(self):
        print("\n  [Salvando todos os dados...]")
        self.salvar_backlog()
        self.salvar_recentes()
        self.salvar_historico()
        print("  Todos os dados foram salvos com sucesso!")

    def carregar_tudo(self):
        print("\n  [Carregando dados salvos...]")
        self.carregar_backlog()
        self.carregar_recentes()
        self.carregar_historico()
        print("  Dados carregados!")

    def menu(self):
        print("\n" + "=" * 50)
        print("           BEM-VINDO AO BATATABIOS!")
        print("=" * 50)

        self.carregar_jogos("dataset.csv")

        self.carregar_tudo()

        while True:
            print("\n" + "-" * 50)
            print("  MENU PRINCIPAL - Escolha uma opção:")
            print("-" * 50)
            print("  1. Listar todos os jogos do catálogo")
            print("  2. Buscar jogo por nome")
            print("  3. Filtrar por gênero")
            print("  4. Filtrar por console")
            print("  5. Filtrar por nota mínima")
            print("  6. Filtrar por vendas mínimas")
            print("  7. Ordenar catálogo")
            print("  8. Adicionar jogo ao backlog")
            print("  9. Ver meu backlog")
            print(" 10. Jogar próximo do backlog")
            print(" 11. Ver jogos recentes")
            print(" 12. Retomar último jogo")
            print(" 13. Registrar tempo de jogo (manual)")
            print(" 14. Ver histórico completo")
            print(" 15. Ver recomendações")
            print(" 16. Ver ranking pessoal")
            print(" 17. Ver dashboard")
            print(" 18. Salvar tudo")
            print(" 19. Sair do programa")
            print("-" * 50)

            opcao = input("  Digite o número da opção: ").strip()

            if opcao == "1":
                self.listar_jogos()
            elif opcao == "2":
                termo = input("  Digite parte do nome do jogo: ")
                self.buscar_jogo_por_nome(termo)
            elif opcao == "3":
                gen = input("  Digite o gênero (ex: Action, RPG, Platform): ")
                self.filtrar_por_genero(gen)
            elif opcao == "4":
                con = input("  Digite o console (ex: PS4, Nintendo Switch, PC): ")
                self.filtrar_por_console(con)
            elif opcao == "5":
                nota = input("  Digite a nota mínima (ex: 85): ")
                self.filtrar_por_nota(nota)
            elif opcao == "6":
                vendas = input("  Digite vendas mínimas em milhões (ex: 20): ")
                self.filtrar_por_vendas(vendas)
            elif opcao == "7":
                print("  Critérios: 1=Título  2=Nota  3=Vendas  4=Data  5=Console  6=Gênero")
                crit = input("  Escolha o critério (1-6): ")
                self.ordenar_jogos(crit)
            elif opcao == "8":
                self.adicionar_ao_backlog()
            elif opcao == "9":
                self.mostrar_backlog()
            elif opcao == "10":
                self.jogar_proximo_do_backlog()
            elif opcao == "11":
                self.mostrar_recentes()
            elif opcao == "12":
                self.retomar_ultimo_jogo()
            elif opcao == "13":
                self.registrar_sessao_manual()
            elif opcao == "14":
                self.mostrar_historico()
            elif opcao == "15":
                self.recomendar_jogos()
            elif opcao == "16":
                self.gerar_ranking_pessoal()
            elif opcao == "17":
                self.exibir_dashboard()
            elif opcao == "18":
                self.salvar_tudo()
            elif opcao == "19":
                print("\n  Salvando antes de sair...")
                self.salvar_tudo()
                print("\n  Obrigado por usar o BatataBios!")
                print("  Feito para o alcidao")
                break
            else:
                print("  Opção inválida! Tente novamente.")


if __name__ == "__main__":
    batata = BatataBios()
    batata.menu()
